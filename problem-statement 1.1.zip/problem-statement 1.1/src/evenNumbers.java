import java.util.*;
public class evenNumbers {
	public static void main(String[] args) {
		Scanner scn=new Scanner(System.in);
		System.out.println("enter a number");
		int n=scn.nextInt();
		System.out.println("the even numbers less than or equal to "+ n + " are : ");
		for(int i=0;i<=n;i++)
		{
			if(i%2==0)
			{
				System.out.println(i );
			}
		}
	}

}
