import java.util.*;
public class ValidShuffleStrings {

    public static void main(String[] args) {
    	Scanner scn=new Scanner(System.in);
    	System.out.println("enter the first string");
    	
    	
    	String s1=scn.next();
    	System.out.println("enter the second string");
    	String s2=scn.next();
    	System.out.println("enter the third string");
    	String s3=scn.next();
   
        
        String results = "Y21XX";
    
        validShuffle(s1, s2, s3);

    }

    private static void validShuffle(String s1, String s2, String s3) {
        
        String res = s1 + s2;
        StringBuffer s = new StringBuffer(res);

        boolean flag = false;

      
		char[] ch = s3.toCharArray();

        if (s.length() != s3.length()) {
            flag = false;
        } else {

            for (int i = 0; i < ch.length; i++) {
                
                String temp = Character.toString(ch[i]);

                if (res.contains(temp)) {

                    s = s.deleteCharAt(s.indexOf(temp));
                    res = new String(s);
                    flag = true;
                    
                } else {
                    flag = false;
                    break;
                }

            }

        }

        if (flag) {
            System.out.println("true: third string is a valid shuffle of first and second Strings");
        } else {
            System.out.println("false: third string is not a valid shuffle of first and second strings");
        }

    }

}