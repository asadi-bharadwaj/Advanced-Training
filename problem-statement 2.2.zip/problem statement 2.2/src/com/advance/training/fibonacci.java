package com.advance.training;

public class fibonacci {
	public static void main(String[] args) {
System.out.println("enter two numbers : "+args[0]+" "+args[1]);
		
		int a=Integer.parseInt(args[0]);
		int b=Integer.parseInt(args[1]);
		int c;
		int n=13;
		for(int i=1;i<=n;i++) {
			System.out.print(a+" ");
			c=a+b;
			a=b;
			b=c;
		}
	}
}
	
