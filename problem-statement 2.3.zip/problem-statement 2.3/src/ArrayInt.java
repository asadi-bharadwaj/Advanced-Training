
public class ArrayInt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	int A[] = {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};
		
		int sum=0;
		int temp;
		
		//loop to calculate sum of elements
		for(int i=0; i<A.length-4;i++)
		{
			sum=sum+A[i];
		}
		System.out.println("sum of elements from index 0 to index 14 are : "+sum);
		
		A[15]=56;
		System.out.println("sum of elements of index 0 to index 14 are calculated and stored it at element 15  ");
		System.out.println("the updated integer array is : ");
		System.out.println("========================================");
		for(int j=0;j<A.length;j++)
		{
			
		System.out.print(A[  j  ]);
		
		}
		for(int k=0;k<A.length;k++)
		{
			sum+=A[k];
		}
			int avg = sum/ A.length;
			
		System.out.println("");
		System.out.println("========================================");
	
		System.out.println("The average of all numbers are : "+ avg);
		A[16]=9;
		System.out.println("the updated integer array is : ");
		System.out.println("========================================");
		for(int x=0;x<A.length;x++)
		{
			System.out.print(A[x]);
		}
		System.out.println("");
		System.out.println("========================================");
		System.out.println("");
		for(int y=0;y<A.length;y++)
		{
			for(int z=y+1;z<A.length;z++)
			{
				if(A[y]>A[z])
				{
					temp=A[y];
					A[y]=A[z];
					A[z]=temp;
					
					
				}
			}
		}
	System.out.println("smallest value from the array is : " +A[0]);
	A[17]=0;
	System.out.println("the updated integer array is : ");
	System.out.println("========================================");
	for(int d=0;d<A.length;d++)
	{
		System.out.print(A[d]);
	}
	System.out.println("");
	System.out.println("========================================");
	
	
		

	}

}
