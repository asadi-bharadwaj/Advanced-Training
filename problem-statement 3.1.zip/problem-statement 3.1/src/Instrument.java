
public abstract class Instrument {
	abstract void play();
}
	class Piano extends Instrument{
		@Override void play() {
			System.out.println("�Piano is playing tan tan tan tan� for Piano class");
		}
	}
	class Flute extends Instrument{
		@Override void play() {
		System.out.println("�Flute is playing toot toot toot toot� for Flute class");
		
	}
	class Guitar extends Instrument{
		@Override void play() {
			System.out.println("�Guitar is playing tin tin tin�  for Guitar class");
		}
	}
		
		
	}
	