
public class expresiion {
	public static  void main(String[] args) {
		String a=("11 +   66 -  ( 55 / 77 )    +   abc   - 99* 65 ");
		String[] b=a.split("\\s");
		for(String Z:b) {
			System.out.println(Z);
			
		}
	}
}
