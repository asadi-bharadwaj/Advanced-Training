import java.util.*;

public class ArrayList1{
	public static void main(String[] args) {
		ArrayList<String> list=new ArrayList<String>();
		list.add("bharadwaj");
		list.add("mahesh");
		list.add("prabhas");
		//traversing the list
		Iterator itr=list.iterator();//getting iterator
		//checking iterator has any elements
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		if(list.contains("bharadwaj")) {
			System.out.println("student name is present");
		}
		else {
			System.out.println("student name not present");
		}
		
	}
}